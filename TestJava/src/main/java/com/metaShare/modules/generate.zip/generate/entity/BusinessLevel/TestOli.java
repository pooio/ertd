package com.metaShare.modules.generate.entity.BusinessLevel;

import com.metaShare.modules.core.entity.CustomBaseEntity;

import java.math.BigDecimal;

public class TestOli extends CustomBaseEntity{
	
	private String oldName;//文本框

	private String singleBox;//单选

	private String checkBox;//多选

	private String enumDropSelect;//枚举类型单选下拉框

	private String dicDropSelect;//字典类型多选下拉框

	private String timePicker;//时间选择器

	private Integer numberAccumulator;//数字累加器

	private BigDecimal decimalNumber;//小数类型字段

	private Boolean flag;//布尔类型

	private String areaText;//文本域

	private String updateTime;

	public Integer getNumberAccumulator() {
		return numberAccumulator;
	}

	public void setNumberAccumulator(Integer numberAccumulator) {
		this.numberAccumulator = numberAccumulator;
	}

	public BigDecimal getDecimalNumber() {
		return decimalNumber;
	}

	public void setDecimalNumber(BigDecimal decimalNumber) {
		this.decimalNumber = decimalNumber;
	}

	public Boolean getFlag() {
		return flag;
	}

	public void setFlag(Boolean flag) {
		this.flag = flag;
	}

	public String getSingleBox() {
		return singleBox;
	}

	public void setSingleBox(String singleBox) {
		this.singleBox = singleBox;
	}

	public String getCheckBox() {
		return checkBox;
	}

	public void setCheckBox(String checkBox) {
		this.checkBox = checkBox;
	}

	public String getEnumDropSelect() {
		return enumDropSelect;
	}

	public void setEnumDropSelect(String enumDropSelect) {
		this.enumDropSelect = enumDropSelect;
	}

	public String getDicDropSelect() {
		return dicDropSelect;
	}

	public void setDicDropSelect(String dicDropSelect) {
		this.dicDropSelect = dicDropSelect;
	}

	public String getTimePicker() {
		return timePicker;
	}

	public void setTimePicker(String timePicker) {
		this.timePicker = timePicker;
	}

	public String getAreaText() {
		return areaText;
	}

	public void setAreaText(String areaText) {
		this.areaText = areaText;
	}

	public String getOldName() {
		return oldName;
	}

	public void setOldName(String oldName) {
		this.oldName = oldName;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
}
