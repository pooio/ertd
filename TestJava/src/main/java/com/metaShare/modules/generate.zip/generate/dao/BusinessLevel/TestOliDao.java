package com.metaShare.modules.generate.dao.BusinessLevel;

import com.metaShare.modules.generate.entity.BusinessLevel.TestOli;

import com.baomidou.mybatisplus.mapper.BaseMapper;

public interface TestOliDao extends BaseMapper<TestOli> {
   
    
}
