package com.metaShare.modules.generate.serviceImpl.BusinessLevel;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.metaShare.common.tool.pageTool.PageDTO;
import com.metaShare.common.tool.pageTool.PageTool;
import com.metaShare.common.tool.state.Result;
import com.metaShare.common.tool.state.ResultCode;
import com.metaShare.common.utils.DateUtil;
import com.metaShare.modules.generate.dao.BusinessLevel.TestOliDao;
import com.metaShare.modules.generate.entity.BusinessLevel.TestEnum;
import com.metaShare.modules.generate.entity.BusinessLevel.TestOli;
import com.metaShare.modules.generate.service.BusinessLevel.TestOliService;
import com.metaShare.modules.sys.dao.SysDictDao;
import com.metaShare.modules.sys.entity.SysDicinfo;
import org.apache.poi.ss.formula.functions.T;
import org.aspectj.weaver.ast.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.Serializable;
import java.util.List;

@Service
public class TestOliServiceImpl extends ServiceImpl<TestOliDao,TestOli> implements TestOliService{

    @Autowired
    private SysDictDao sysDictDao;

    @Override
    public boolean insert(TestOli entity) {
        entity.setUpdateTime(DateUtil.getDate(DateUtil.timeStampPattern));
        return super.insert(entity);
    }

    @Override
    public boolean updateById(TestOli entity) {
        entity.setUpdateTime(DateUtil.getDate(DateUtil.timeStampPattern));
        return super.updateById(entity);
    }


    /**
     * 获取列表数据
     * @param pageNum
     * @param pageSize
     * @return
     */
    @Override
    public Result selectList(int pageNum,int pageSize) {
        try {
            List<TestOli> listInfo = this.selectList(null);
            int total = listInfo.size();
            PageDTO pageDTO = new PageTool<TestOli>().getPage(listInfo, pageSize, pageNum);
            return Result.resultInfo(ResultCode.SUCCESS,total,pageDTO.getData());
        } catch (Exception e) {
            e.printStackTrace();
            return Result.resultInfo(ResultCode.FAILURE,"获取列表数据失败");
        }
    }
    /**
     * 获取枚举列表
     * @return
     */
    @Override
    public Result getEnumList() {
        try {
            List enumList = TestEnum.findEnumList(TestEnum.TestOliType);
            return Result.resultInfo(ResultCode.SUCCESS,enumList);
        } catch (Exception e) {
            e.printStackTrace();
            return Result.resultInfo(ResultCode.FAILURE,"获取枚举列表失败");
        }
    }

    /**
     * 获取字典列表
     * @param dicCode
     * @return
     */
    @Override
    public Result getDicList(String dicCode) {
        try {
            List<SysDicinfo> dicList = sysDictDao.getDictList(dicCode);
            return Result.resultInfo(ResultCode.SUCCESS,dicList);
        } catch (Exception e) {
            e.printStackTrace();
            return Result.resultInfo(ResultCode.FAILURE,"获取字典列表失败");
        }
    }
}
