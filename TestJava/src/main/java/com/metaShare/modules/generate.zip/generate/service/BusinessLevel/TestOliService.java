package com.metaShare.modules.generate.service.BusinessLevel;

import com.baomidou.mybatisplus.service.IService;
import com.metaShare.common.tool.state.Result;
import com.metaShare.modules.generate.entity.BusinessLevel.TestOli;

public interface TestOliService extends IService<TestOli> {

    Result selectList(int pageNum,int pageSize);

    Result getEnumList();

    Result getDicList(String dicCode);
}
