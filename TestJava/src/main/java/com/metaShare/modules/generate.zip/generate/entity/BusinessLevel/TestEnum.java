package com.metaShare.modules.generate.entity.BusinessLevel;

import java.util.*;

public enum TestEnum {

	/* 成功状态码 */
	SUCCESS(0, "成功"),

	/**
	 * SysConfigType
	 * 系统配置--配置类型
	 */
	TestOliType,
	TestOliType1(1,"枚举选项一",TestOliType),
	TestOliType2(2,"枚举选项二",TestOliType),
	;
	private Object value;// 值

	private String desc;// 描述

	private TestEnum type;// 类型
	TestEnum() {
	}

	TestEnum(Object value) {
		this.value = value;
	}

	TestEnum(Object value , String desc) {
		this.value = value;
		this.desc = desc;
	}
	TestEnum(Object value , String desc, TestEnum type) {
		this.value = value;
		this.desc = desc;
		this.type = type;
	}
	
	public String getDesc() {
		return desc;
	}

	public Object getValue() {
		return value;
	}
	
	public int getIntValue() {
		return Integer.parseInt(value.toString());
	}
	
	public String getStrValue() {
		return value.toString();
	}
	
	public TestEnum getType() {
		return type;
	}

	/**
	  * @Title findEnumList
	  * @Description TODO 根据枚举常量类型 获取枚举值集合
	  * @param type
	  * @return  设定文件
	  * @return Map<Object,String>    返回类型
	  * @author XIDF
	  * @company 
	  * @date 
	 */
	public static Map<Object, String> findEnumMap(TestEnum type) {
        EnumSet<TestEnum> currEnumSet = EnumSet.allOf(TestEnum.class);
        Map<Object, String> map = new HashMap<>();
        for (TestEnum ts : currEnumSet) {
        	if(type.equals(ts.getType()))
        		map.put(ts.getValue(), ts.getDesc());
        }
        return map;
    }
	public static List findEnumList(TestEnum type) {
        EnumSet<TestEnum> currEnumSet = EnumSet.allOf(TestEnum.class);
        List<Map<String, String>> list = new ArrayList<Map<String, String>>();
        for (TestEnum ts : currEnumSet) {
        	if(type.equals(ts.getType())){
        		 Map<String,String > map = new HashMap<>();
        		 map.put("key",ts.getValue().toString());
        		 map.put("value",ts.getDesc());
        		list.add(map);
        	}
        		
        }
        return list;
    }

}
