package com.metaShare.modules.generate.controller.BusinessLevel;

import com.metaShare.modules.generate.entity.BusinessLevel.TestOli;
import com.metaShare.modules.generate.service.BusinessLevel.TestOliService;
import com.metaShare.modules.generate.serviceImpl.BusinessLevel.TestOliServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import com.metaShare.common.tool.state.Result;
import com.metaShare.common.tool.state.ResultCode;
import com.metaShare.modules.BaseController;

import java.util.List;


/**
 * Created by pc on 2020/1/12.
 */
@Controller
@CrossOrigin
@RequestMapping("/api/generate/TestOli")
public class TestOliController extends BaseController {

	@Autowired
	private TestOliService testOliService;

	/**
	 * 保存数据
	 * @param testOli
	 * @return
	 */
	@RequestMapping(value = "/save", method = { RequestMethod.POST })
	@ResponseBody
	public Result save(TestOli testOli) {
		try {
			boolean flag =  testOliService.insert(testOli);
			if(flag){
				return Result.resultInfo(ResultCode.SUCCESS,"保存成功");
			}else{
				return Result.resultInfo(ResultCode.FAILURE,"保存失败");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return Result.resultInfo(ResultCode.FAILURE,"保存失败");
		}
	}

	/**
	 * 编辑数据
	 * @param testOli
	 * @return
	 */
	@RequestMapping(value = "/update", method = { RequestMethod.POST })
	@ResponseBody
	public Result update(TestOli testOli) {
		try {
			boolean flag = testOliService.updateById(testOli);
			if(flag){
				return Result.resultInfo(ResultCode.SUCCESS,"编辑成功");
			}else{
				return Result.resultInfo(ResultCode.FAILURE,"编辑失败");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return Result.resultInfo(ResultCode.FAILURE,"编辑失败");
		}
	}

	/**
	 * 删除数据
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/del", method = { RequestMethod.POST })
	@ResponseBody
	public Result del(String id) {
		try {
			boolean flag = testOliService.deleteById(id);
			if(flag){
				return Result.resultInfo(ResultCode.SUCCESS,"删除成功");
			}else{
				return Result.resultInfo(ResultCode.FAILURE,"删除失败");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return Result.resultInfo(ResultCode.FAILURE,"删除失败");
		}
	}

	/**
	 * 获取数据信息
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/getInfo")
	@ResponseBody
	public Result getInfo(String id){
		try {
			TestOli testOli = testOliService.selectById(id);
			return Result.resultInfo(ResultCode.SUCCESS,testOli);
		} catch (Exception e) {
			e.printStackTrace();
			return Result.resultInfo(ResultCode.FAILURE,"获取数据失败");
		}
	}

	/**
	 * 分页获取列表
	 * @param pageNum
	 * @param pageSize
	 * @return
	 */
	@RequestMapping(value = "/list", method = { RequestMethod.POST })
	@ResponseBody
	public Result list(int pageNum, int pageSize) {
		try {
			return testOliService.selectList(pageNum,pageSize);
		} catch (Exception e) {
			e.printStackTrace();
			return Result.resultInfo(ResultCode.FAILURE,"获取列表失败");
		}
	}

	/**
	 * 获取全部数据
	 * @return
	 */
	@RequestMapping(value = "/allList", method = { RequestMethod.POST })
	@ResponseBody
	 public Result allList() {
		try {
			List<TestOli> testOliList = testOliService.selectList(null);
			return Result.resultInfo(ResultCode.SUCCESS,testOliList);
		} catch (Exception e) {
			e.printStackTrace();
			return Result.resultInfo(ResultCode.FAILURE,"获取列表数据失败");
		}
	}

	/**
	 * 获取枚举列表
	 * @return
	 */
	@RequestMapping(value = "/getEnumList")
	@ResponseBody
	public Result getEnumList(){
		try {
			return testOliService.getEnumList();
		} catch (Exception e) {
			e.printStackTrace();
			return Result.resultInfo(ResultCode.FAILURE,"获取枚举列表失败");
		}
	}

	/**
	 * 获取字典列表
	 * @param dicCode
	 * @return
	 */
	@RequestMapping(value = "/getDicList")
	@ResponseBody
	public Result getDicList(String dicCode){
		try {
			return testOliService.getDicList(dicCode);
		} catch (Exception e) {
			e.printStackTrace();
			return Result.resultInfo(ResultCode.FAILURE,"获取字典列表失败");
		}
	}


}
